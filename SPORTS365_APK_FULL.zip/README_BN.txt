SPORTS365 APK — GitHub দিয়ে বানানোর ধাপ (কম্পিউটার/Android Studio ছাড়াই)

1) github.com-এ Login → New repository → নাম: sports365app → Private → Create
2) "uploading an existing file" চাপুন → এই ZIP খুলে ভেতরের সব ফাইল/ফোল্ডার আপলোড করুন
   (.github, app, build.gradle, settings.gradle, gradle.properties — সব)
   ফোনে .github আপলোড না হলে: Add file > Create new file → নাম দিন  .github/workflows/build-apk.yml  → এই ZIP-এর ওই ফাইলের লেখা পেস্ট করুন
3) Commit changes চাপুন
4) Actions ট্যাব → "Build APK" → Run workflow → ৩-৫ মিনিট অপেক্ষা
5) সবুজ টিক এলে run খুলুন → নিচে Artifacts → sports365-apk নামান (ভেতরে sports365.apk)
6) সাইটের /downloads/sports365.apk-এ আপলোড করুন (পুরনোটা ব্যাকআপ রেখে)
7) ফোনে পুরনো অ্যাপ আনইনস্টল করে নতুনটা ইনস্টল করুন

সাইটের ঠিকানা বদলাতে: app/src/main/res/values/strings.xml (start_url, site_host) — তারপর আবার Run workflow।
এই অ্যাপ targetSdk 34 — "পুরনো Android-এর জন্য বানানো" ব্লক আসবে না।
