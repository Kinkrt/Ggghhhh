package club.sports365.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.util.ArrayList;

/** SPORTS365 — ওয়েবসাইট WebView-তে। localStorage(token) চালু, গেমের নতুন-উইন্ডো (window.open) সাপোর্ট, ফাইল-আপলোড, Back-বাটন। */
public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView web;
    private View errorView;
    private final ArrayList<WebView> popups = new ArrayList<>();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQ = 1001;
    private String host;

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        host = getString(R.string.site_host);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF141414);
        setContentView(root);
        web = makeWebView();
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        if (b != null) web.restoreState(b); else load();
    }

    private void load() {
        if (!online()) { showError(); return; }
        hideError();
        web.loadUrl(getString(R.string.start_url));
    }

    private boolean online() {
        try { ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE); NetworkInfo n = cm.getActiveNetworkInfo(); return n != null && n.isConnected(); }
        catch (Exception e) { return true; }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView makeWebView() {
        WebView w = new WebView(this);
        w.setBackgroundColor(0xFF141414);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString() + " Sports365App/1.0");
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return handleUrl(r.getUrl()); }
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame() && v == web) showError();
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            // গেম/পপআপ: window.open() → উপরে নতুন WebView
            @Override public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message resultMsg) {
                WebView pw = makeWebView();
                popups.add(pw);
                root.addView(pw, new FrameLayout.LayoutParams(-1, -1));
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(pw); resultMsg.sendToTarget();
                return true;
            }
            @Override public void onCloseWindow(WebView v) { closePopup(v); }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_REQ); }
                catch (ActivityNotFoundException e) { fileCallback = null; return false; }
                return true;
            }
        });
        // APK/ফাইল ডাউনলোড → ব্রাউজারে
        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
        });
        return w;
    }

    /** true = আমরা হ্যান্ডেল করেছি (WebView-তে লোড হবে না) */
    private boolean handleUrl(Uri u) {
        String sch = u.getScheme() == null ? "" : u.getScheme();
        if (sch.equals("http") || sch.equals("https")) {
            String h = u.getHost() == null ? "" : u.getHost();
            if (h.equals(host) || h.endsWith("." + host)) return false;
            // বাইরের সাইট (Payment/Telegram/WhatsApp ইত্যাদি) → সিস্টেম ব্রাউজার; গেম-প্রোভাইডারও যেন কাজ করে তাই শুধু পরিচিত লিংক বাইরে খুলি
            String s = u.toString();
            if (h.contains("t.me") || h.contains("wa.me") || h.contains("whatsapp") || h.contains("telegram") || h.contains("facebook") || s.endsWith(".apk")) { openExternal(u); return true; }
            return false; // গেম/Payment পেজ অ্যাপের ভেতরেই
        }
        openExternal(u); return true; // tel:, mailto:, intent:, ইত্যাদি
    }

    private void openExternal(Uri u) { try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { } }

    private void closePopup(WebView v) {
        if (popups.remove(v)) { root.removeView(v); v.destroy(); }
    }

    private void showError() {
        if (errorView != null) return;
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xFF141414);
        android.widget.LinearLayout l = new android.widget.LinearLayout(this);
        l.setOrientation(android.widget.LinearLayout.VERTICAL); l.setGravity(android.view.Gravity.CENTER); l.setPadding(60, 60, 60, 60);
        android.widget.TextView t = new android.widget.TextView(this);
        t.setText("ইন্টারনেট সংযোগ নেই\nসংযোগ ঠিক করে আবার চেষ্টা করুন"); t.setTextColor(0xFFE5E7EB); t.setTextSize(16); t.setGravity(android.view.Gravity.CENTER);
        android.widget.Button bt = new android.widget.Button(this); bt.setText("আবার চেষ্টা করুন");
        bt.setOnClickListener(v -> { hideError(); load(); });
        l.addView(t); l.addView(bt);
        f.addView(l, new FrameLayout.LayoutParams(-1, -1, android.view.Gravity.CENTER));
        errorView = f; root.addView(f, new FrameLayout.LayoutParams(-1, -1));
    }

    private void hideError() { if (errorView != null) { root.removeView(errorView); errorView = null; } }

    @Override public void onBackPressed() {
        if (!popups.isEmpty()) { WebView p = popups.get(popups.size() - 1); if (p.canGoBack()) p.goBack(); else closePopup(p); return; }
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCallback = null;
        } else super.onActivityResult(req, res, data);
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
}
